namespace Arms.Domain.Entities
{
    public enum EmployeeGender
    {
        Male = 1,
        Female = 2
    }
}