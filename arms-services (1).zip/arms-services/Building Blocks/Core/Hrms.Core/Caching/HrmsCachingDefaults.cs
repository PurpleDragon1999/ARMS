namespace Hrms.Core.Caching
{
    /*
     * Author: AV
     * Date: June 2019
     */
    public class HrmsCachingDefaults
    {
        /// <summary>
        /// Gets the default cache time in minutes
        /// </summary>
        public static int CacheTime => 60;
    }
}