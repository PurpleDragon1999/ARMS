namespace Hrms.Core.Configuration
{
    /// <summary>
    /// Setting interface
    /// </summary>
    public interface ISettings
    {
        
    }
}