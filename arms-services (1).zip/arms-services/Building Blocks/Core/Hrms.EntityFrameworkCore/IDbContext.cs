namespace Hrms.EntityFrameworkCore
{
    public interface IDbContext
    {
        
    }
}